from pathlib import Path

# Set your root directory where the search begins.
root_dir = Path(r"C:\Users\clear\Desktop\SpiritBe")

# Define the allowed file extensions (add more if needed)
allowed_extensions = {'.css', '.html', '.py', '.js'}

# List to accumulate the output lines
output_lines = []

# Traverse through every file in the directory tree
for file_path in root_dir.rglob("*"):
    # Skip if the file/directory path contains '.venv' or 'node_modules'
    if ".venv" in file_path.parts or "node_modules" in file_path.parts:
        continue
    
    if file_path.is_file():
        ext = file_path.suffix.lower()
        if ext in allowed_extensions:
            try:
                file_content = file_path.read_text(encoding="utf-8")
            except Exception as e:
                file_content = f"Error reading file: {e}"

            # Keep all lines (no filtering of import/from)
            filtered_content = file_content

            # Get the relative path from the root directory
            try:
                relative_path = file_path.relative_to(root_dir)
            except ValueError:
                relative_path = file_path

            # Append the file header and content to the list
            output_lines.append(f"FILE: {file_path.name} AT ROOT/{relative_path}\n")
            output_lines.append(filtered_content)
            output_lines.append("\n" + "*" * 50 + "\n")

# Combine all collected output into one string
output_str = "\n".join(output_lines)

# Define the output file path
output_file = Path(r"C:\Users\clear\Desktop\SpiritBe\Output.txt")

# Ensure the output directory exists
output_file.parent.mkdir(parents=True, exist_ok=True)

# Write the result to the output file using UTF-8 encoding
with open(output_file, "w", encoding="utf-8") as f:
    f.write(output_str)

print(f"Output written to {output_file}")
